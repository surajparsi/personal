
1. INTRODUCTION

The CommandLineRegressionTest tool is an application to run application independent regression test directly from the opertive system command line tool.
The regression tester provides functionality to test ECU programming, function parameter reading and adjustments.
Can be used for e.g. nightly tests or long time running tests.



2. START A REGRESSION TEST

A regression test can be started by:
	* Using the START.bat from the installation folder.
	* Using the "CommandLineRegressionTest.exe" in the "Bin" folder from the installation folder.

To start a regression test using the the START.bat, you need to modify the file in order to start the test with the right parameters.
The contents from the START.bat should look like this:
CommandlineRegressionTest.exe --configFile="C:\Config\RegressionTestConfig.xml" --execMode="OFFLINE" --system="S8"

Check the section 3 of this readme file to learn more about the supported application arguments.

The START.bat file allows you to start a regression test without needing to specify the arguments every time you need to test your system(s).


3. SUPPORTED APPLICATION ARGUMENTS

List of arguments supported by the "CommandlineRegressionTest.exe". All arguments must be preceeded by "--" characters.

	--configFile		Required Parameter. The path to the regression test configuration XML file.
						Supported Values:
							* Absolute and relative paths
							* Relative paths are relative from the CommandlineRegressionTest.exe location.
						
	--execMode			Required Parameter. Indicates if the test should run connected to an Ecu.
						Supported values:
							* ONLINE
							* OFFLINE
						
						The value of this parameter is NOT case sensitive.
						
	--system			Required Parameter.	The system to test.
						Supported Values:
							* The specified system must be supported by the regression test configuration file
						
						The value of this parameter is case sensitive.
	
	--outputMode		Optional Parameter. Controls the application verbosity mode.
						Supported Values:
							* Full		Current Progress, current sops in test and regression test summaries are printed to the console
							* Compact	One single row for each of the tested sopses containing Sops name, Test session and Passed/Failed status.
						
						The value of this parameter is NOT case sensitive.
