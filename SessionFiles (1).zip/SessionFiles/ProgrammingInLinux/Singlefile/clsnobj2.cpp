#include<iostream>
#include<string>
class Account 
{
  int id;
  std::string name;
  double balance;
  public:
    void init(int, std::string ,double);
    void credit(double);
    void debit(double);
    void display();
    double getBalance() 
    {
      return balance;
    }
};
void Account::init(int x, std::string str, double y) 
{
  id=x;
  name=str;
  balance=y;
}
void Account::credit(double amount) 
{
  balance += amount;
}
void Account::debit(double amount) 
{
  balance-=amount;
}
void Account::display()  
{
  //print id, name, balance
}
//int a  = __INT_MAX__ +1;
int main() 
{
  Account a1;
  a1.init(1001, "Pisers", 56000);
  a1.credit(1000);
  a1.debit(29500);
  std::cout << a1.getBalance() << "\n";
  Account a2;
  a2.init(1002, "Sandeep", 80000);
  a2.debit(50000);
  a2.credit(1000);
  std::cout << a2.getBalance() << "\n";
  //a1.balance = 5000;
  //std::cout << a1.balance;
  return 0;
}