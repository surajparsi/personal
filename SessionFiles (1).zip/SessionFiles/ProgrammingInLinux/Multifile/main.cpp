#include "account.h"
#include <iostream>
int main() 
{
  Account a1;
  a1.init(1001, "Pisers", 56000);
  a1.credit(1000);
  a1.debit(29500);
  std::cout << a1.getBalance() << "\n";
  Account a2;
  a2.init(1002, "Sandeep", 80000);
  a2.debit(50000);
  a2.credit(1000);
  std::cout << a2.getBalance() << "\n";
  //a1.balance = 5000;
  std::cout << MACRO;
  //std::cout << a1.balance;
  return 0;
}

