#include "stdio.h"

int main()
{
    printf("MACRO = %d\n", MACRO);
}