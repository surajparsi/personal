#ifndef __ACCOUNT_H
#define __ACCOUNT_H
#include<iostream>
//#define MACRO
class Account 
{
  int id;
  std::string name;
  double balance;
  public:
    void init(int, std::string, double); 
    void credit(double); 
    void debit(double); 
    double getBalance(); 
    void display();  
};
#endif