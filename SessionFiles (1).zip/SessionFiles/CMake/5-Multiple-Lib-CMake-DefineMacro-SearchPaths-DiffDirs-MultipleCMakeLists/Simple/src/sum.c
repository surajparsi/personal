#include "fun.h"
int sum(int z, int y) {
  //Adding Macros like offset
  int total  = z + y + SUM_OFFSET;
  return total;
}
