Build System (Make) Pros:
1. Automate tasks
2. Build Optimization
3. Dependency track/graphs

Build System (Make) Cons:
1. Manual coding 
2. Writing commands - Platform dependency
3. IDE support is not available

Build System Generators (CMake, Autotools, SCons, Meson, Bazel, ....):
1. Autogenerate Build Systems files (Makefiles, ..... )
2. Understanding your project  - Language support
3. IDE support is available

CMake (Pros):
1. Works implicitly with Makefiles (Support for Ninja, .....)
2. No hardcoding is required
3. CI support is available
4. Platform dependency is removed
5. Working with Paths is easy
6. Debugger support

