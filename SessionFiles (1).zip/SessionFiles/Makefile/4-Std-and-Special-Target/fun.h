#ifndef __FUN_H
#define __FUN_H
int sum(int x, int y);
int square(int x);
#endif
