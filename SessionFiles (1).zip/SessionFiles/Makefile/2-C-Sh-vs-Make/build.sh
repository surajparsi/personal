#! /bin/bash
# Shell Script for Building .c file(s)
# Comments start with #
# echo command prints string in terminal
clear
echo "----- Build Process initiated -----"
ls
echo "----- Removing all files with .o, .out extensions -----"
rm *.o *.out
ls
echo "----- Compiling test.c -----"
gcc -c test.c
ls
echo "----- Compiling sum.c -----"
gcc -c sum.c
ls
echo "----- Compiling sqr.c -----"
gcc -c sqr.c
ls
echo "----- Creating an executable -----"
gcc test.o sum.o sqr.o -o all.out
ls
echo "----- Running executable -----"
./all.out
