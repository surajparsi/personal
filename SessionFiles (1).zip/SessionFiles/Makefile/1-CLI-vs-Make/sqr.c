#include "fun.h"
int square(int q) {
return q * q * q;
}
