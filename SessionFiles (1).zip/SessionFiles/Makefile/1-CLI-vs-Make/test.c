#include "fun.h"
#include <stdio.h>
int main() {
  int a, b, c, d, e;
  a = 10;
  b = 20;
  c = sum(a, b);
  d = square(a);
  e = sum(a,b+10);
  printf("c=%d,d=%d,e=%d\n",c,d,e);
  return 0;
}