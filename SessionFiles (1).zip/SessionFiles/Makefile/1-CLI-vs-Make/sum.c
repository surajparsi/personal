#include "fun.h"
int sum(int x, int y) {
  return x + y;
}
