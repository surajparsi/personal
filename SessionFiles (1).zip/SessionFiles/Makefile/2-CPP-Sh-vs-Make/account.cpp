#include "account.h"
void Account::init(int x, std::string str, double y) 
{
  id=x;
  name=str;
  balance=y;
}
void Account::credit(double amount) 
{
  balance += amount;
}
void Account::debit(double amount) 
{
  balance-=amount;
}
void Account::display()  
{
  //print id, name, balance
}
double Account::getBalance() 
{
  return balance;
}