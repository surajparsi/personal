#! /bin/bash
# Shell Script for Building .cpp file(s)
# Comments start with #
# echo command prints string in terminal

clear
echo "----- Build Process initiated -----"
ls
echo "----- Removing all files with .o, .out extensions -----"
rm *.o *.out
ls
echo "----- Compiling account.cpp -----"
g++ -c account.cpp
ls
echo "----- Compiling main.cpp -----"
g++ -c main.cpp
ls
echo "----- Creating an executable -----"
g++ account.o main.o -o account.out
ls
echo "----- Running executable -----"
./account.out
