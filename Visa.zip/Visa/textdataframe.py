import os
import openpyxl
import xml.etree.ElementTree as ET
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter



def txt_extract() :
	text_file = (r'BCI\03 RegressionTestFiles\Result\BCI2\BCI2_SOP2110\BCI2_2021-10-29 13_46_2_143_Online\Psm_coverage_psm_dev.txt')
	words= {}	  
	with open(text_file,"r") as file:
				data = file.readlines()
				try :
					for index,line in enumerate(data):
						if index > 5 :
						    keys =line.split(" ")[0]
                            value=float(line.split(" ")[-1])
                            if keys not in words.keys() :
                                words[keys] = []
								words[keys].append(value)
						    else: 
								words[keys].append(value)	   
				except :
					pass
    text_data = {}
    for coverage_key in words:
        coverage_value = sum(words[coverage_key])*100/len(words[coverage_key])
        text_data[coverage_key]=coverage_value
    print(text_data)

# def psm_xml () : 
    # xml_parameter=[]
    # root = ET.parse(r'D:\Jenkins\workspace\poc_RTE\psm\BCI2.xml').getroot()
    # for child in root.iter('Parameter'):
    # for child in root:
        # xml_parameter.append(child.attrib['obj'])
    # print(xml_parameter)
	
# psm_xml()




# def psm_xml():
    # xml_parameter = []
    # root = ET.parse(r'D:\Jenkins\workspace\poc_RTE\psm\BCI2.xml')
    # for child in root.iter('Parameter'):
        # xml_parameter.append(child.attrib['obj'].strip())
    # print("xml:",xml_parameter)
    # return xml_parameter

# def excel_parameters():
    # wb = load_workbook(r"C:\Users\SPA9DA\Downloads\Individual parameter coverage - Template.xlsx")
    # ws = wb["Sheet1"]
    # return ws

# def parameter_names():
    # parameter_name = []
    # ws = excel_parameters()
    # for ro in range(7, ws.max_row):
        # s = ws.cell(row = ro, column = 2)
        # parameter_name.append(s.value)
    # while None in parameter_name:
        # parameter_name.remove(None)
    # print("excel:",parameter_name)
    # return parameter_name

# def missing_parameter():
    # missing_parameters = []
    # para = parameter_names()
    # sample = psm_xml()
    # for i in para:
        # if i not in sample:
            # missing_parameters.append(i)
    # print(missing_parameters)
    # return missing_parameters
	
# missing_parameter()