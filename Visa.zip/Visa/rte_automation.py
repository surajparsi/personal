"""
Usage:
Get All Changeset and owner for Hanging Branches
    python rte_automation.py -x "config xml" -m "execution mode" -s "system name"
    eg: python rte_automation.py  -x BCI2_Jenkins_Automation.xml -m OFFLINE -s BCI2

Information:
Option -x   : config xml file - Should provide 
Option -m   : execution mode for RegressionTestExcution - Should provide 
Option -s   : system name for RegressionTestExcution - Should provide 
"""



import argparse
from distutils import dir_util
from distutils.command.config import config
from functools import total_ordering
import os,sys
import os.path
from pickle import NONE
import subprocess
import openpyxl
import xml.etree.ElementTree as ET
from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill, Side, borders, Font, Alignment
from subprocess import Popen, PIPE
from os import path
from bs4 import BeautifulSoup

var = ''

class RegressionTestExcution():

    """
    Regression Test Framework
    1. Running Regression test tool
    2. Checking for html test report
    3. Checking for paramater value
    """

    def __init__(self, xmlfile,mode,system):
        self.rte_xml_file = xmlfile
        self.sytem_name = system
        self.mode_name = mode
        self.regression_path = os.path.abspath("..")
        self.excel_extract = self.xl_parameters()
        self.psm = self.psm_xml()
        
    
    def missing_parameter(self):
        missing_parameters = []
        name = "Missing Parameters"
        missing_parameters = list(set(self.excel_extract.keys()) - set(self.psm))
        missing_parameters.extend(list(set(self.psm) - set(self.excel_extract.keys())))
        if missing_parameters:
            self.xl_writing(name, missing_parameters)
        else :
            self.rte_excution()

	
    def rte_excution(self):
        
        config_path = os.path.join(self.regression_path,"03 RegressionTestFiles","Configurations","Config_BCI2")
        folder_path = r"D:\Jenkins\Regression Test Framework"
        workspace = os.getcwd()
        cmd = "CommandlineRegressionTest.exe --configFile=\""+ config_path +"\\"+ self.rte_xml_file +"\" --execMode=\"" + self.mode_name+ "\" --system=\"" +  self.sytem_name+ "\""
        os.chdir(folder_path)
        subprocess.call(cmd, shell=True)
        os.chdir(workspace)
        self.calculation_html()
    
    def calculation_html(self):
	
        global var
        directory = os.path.join(self.regression_path,"03 RegressionTestFiles","Result","BCI2","BCI2_SOP2110")
        folder =[name for name in os.listdir(directory) if os.path.isdir(os.path.join(directory, name))]
        self.folder_path =os.path.join(directory,folder[-1])
        html_file =os.path.join(self.folder_path,"TestReport.html")
        
        with open(html_file) as f:
            content = f.read()
            soup = BeautifulSoup(content, 'html.parser')
            for tag in soup.find_all('td'):
                if ((tag.get('id') == "Skipped") or (tag.get('id') == "Failed")):
                    var = "Found failure case in SOPS \n"
                    break                     
        self.coverage_results(folder_path=self.folder_path)
		
    def txt_extract(self,folder_path=None) :
        text_file =os.path.join(folder_path, "Psm_coverage_psm_dev.txt")
        words= {}	  
        total = 'AVERAGE PARAMETER COVERAGE'
        with open(text_file,"r") as file:
            data = file.readlines()
            copy = False
            for line in data:
                if "-- AVERAGE PID COVERAGE --" in line:
                    copy = True
                    continue
                elif "-- AVERAGE PARAMETER COVERAGE --" in line:
                    copy = False
                    continue
                elif copy:
                    line = line.strip()
                    keys = line.split(" ")[0]
                    value = float(line.split(" ")[-1].replace(",", "."))
                    if keys not in words.keys():
                        words[keys] = []
                        words[keys].append(value)
                    else:
                        words[keys].append(value)

            words[total]=[]
            for para in data:
                if(total in para):
                    words[total].append(float(para.split(" ")[-1].strip()))
        text_data = {}
        for coverage_key in words:
            coverage_value = sum(words[coverage_key])*100/len(words[coverage_key])
            text_data[coverage_key]=coverage_value
        return text_data

    def psm_xml(self):
        xml_parameter = []
        root = ET.parse(os.path.abspath(r'..\..\BCI2.xml')).getroot()
        for child in root.iter('Parameter'):
            for para in child.iter('FpcConditionValueSetter') :
                xml_parameter.append(child.attrib['obj'].strip())
        xml_parameter = list(set(xml_parameter))
        return xml_parameter

    def xl_parameters(self):
        
        wb = load_workbook(os.path.join(self.regression_path,"03 RegressionTestFiles","Individual parameter coverage.xlsx"))
        ws = wb["Sheet1"]

        start_row = 0
        start_col = 0

        for row in ws:
            for cell in row:
                if cell.value == "Parameter Name":
                    start_row = cell.row
                    start_col = cell.column
                    break

        parameter_name = {}
        for row in range(start_row + 1, ws.max_row + 1):
            s = ws.cell(row=row, column=start_col)
            if s.value is not None :
                parameter_name[s.value.strip()] = ws.cell(row=row, column=start_col+1).value
        return parameter_name


    def coverage_results(self,folder_path=None):
        sheet_name = "Coverage Results"
        result = []
        for i in self.excel_extract.keys():
            if i in self.txt_extract(folder_path=folder_path).keys():
                # if self.txt_extract(folder_path=folder_path)[i] < self.excel_extract[i]:
                result.append((i, self.excel_extract[i], self.txt_extract(folder_path=folder_path)[i]))
            else : 
                result.append((i,self.excel_extract[i],0))
        result.append(('AVERAGE PARAMETER COVERAGE', 0, self.txt_extract(folder_path=folder_path)['AVERAGE PARAMETER COVERAGE']))
        self.xl_writing(sheet_name,result)


    def xl_writing(self,sheet_name, values):

        xlsx_file=os.path.join(self.regression_path,"03 RegressionTestFiles","Result","BCI2")
        for file in os.listdir(xlsx_file):
            if file.endswith('.xlsx') or file.endswith('.xls'):
                os.remove(os.path.join(xlsx_file,file))
        
        side = Side(border_style="thick")
        border = borders.Border(
            left=side,
            right=side,
            top=side,
            bottom=side,
        )

        wb2 = Workbook()
        ws2 = wb2.create_sheet(sheet_name, 0)


        ws2["B2"] = sheet_name
        ws2["B2"].font = Font(color="ffffff", size="18", bold=True)
        ws2["B2"].fill = PatternFill("solid", start_color="0458AB")
        ws2['B2'].alignment = Alignment(horizontal='center', vertical='center')

        ws2['B3'] = "Parameter Name"
        ws2['B3'].alignment = Alignment(horizontal='center', vertical='center')
        ws2['C3'] = "PSM / Excel "
        ws2['C3'].alignment = Alignment(horizontal='center', vertical='center')
        ws2['B3'].fill = PatternFill("solid", start_color="96be25")
        ws2['B3'].font = Font(color="000000", size="11", bold=True)
        ws2['C3'].fill = PatternFill("solid", start_color="96be25")
        ws2['C3'].font = Font(color="000000", size="11", bold=True)

        if sheet_name == "Missing Parameters":
            ws2.merge_cells("B2:C2")
            s = values
            for row in range(0, len(s)):
                for col in range(1, 2):
                    if s[row] in self.excel_extract and s[row] not in self.psm :
                        ws2[chr(66)+str(row + 4)] = s[row]
                        ws2[chr(67) + str(row + 4)] = "Not in PSM"
                    else :
                        ws2[chr(66)+str(row + 4)] = s[row]
                        ws2[chr(67) + str(row + 4)] = "Not in Excel"
            
            for row in range(2, ws2.max_row + 1):
                for col in range(2, ws2.max_column + 1):
                    ws2.cell(row=row, column=col).border = border
                    ws2.cell(row=row, column=col).alignment = Alignment(horizontal='center', vertical='center')

            ws2.column_dimensions["B"].width, ws2.column_dimensions["C"].width = 50, 18
            ws2.sheet_view.showGridLines = False
            wb2.save(os.path.join(self.regression_path,"03 RegressionTestFiles","Result","BCI2","Missing_Parameters.xlsx"))
            wb2.close()

        else:
            ws2.merge_cells("B2:D2")
            ws2.merge_cells("C3:D3")
            ws2.merge_cells("B3:B4")
            ws2['C2'].border = border
            ws2['B4'].border = border
            ws2['D2'].border = border
            ws2['D3'].border = border
            ws2['G2'].alignment = Alignment(horizontal='center', vertical='center')
            ws2["G2"] = "SOPS"
            ws2.column_dimensions["G"].width = 40
            ws2['G2'].fill = PatternFill("solid", start_color="96be25")
            ws2['G2'].border = border
            ws2['D2'].border = border
            ws2["C4"].value = "Reference"
            ws2['C4'].fill = PatternFill("solid", start_color="96be25")
            ws2["D4"].value = "Actual"
            ws2['D4'].fill = PatternFill("solid", start_color="96be25")
            s = values
            
            if var:
                ws2['G3'].value = var
                ws2['G3'].border = border
            for row in range(0, len(s)):
                for col in range(1, 3):
                    ws2[chr(66) + str(row + 5)] = s[row][0]
                    if s[row][1] > s[row][2]:
                        ws2[chr(67) + str(row + 5)] = s[row][1]
                        ws2[chr(68) + str(row + 5)] = s[row][2]
                        ws2[chr(68) + str(row + 5)].fill = PatternFill("solid", start_color="FF8A8A")
                    else:
                        ws2[chr(67) + str(row + 5)] = s[row][1]
                        ws2[chr(68) + str(row + 5)] = s[row][2]

            for row in range(2, ws2.max_row + 1):
                for col in range(2, 5):
                    ws2.cell(row=row, column=col).border = border
                    ws2.cell(row=row, column=col).alignment = Alignment(horizontal='center', vertical='center')
            
            ws2.column_dimensions["B"].width, ws2.column_dimensions["C"].width,ws2.column_dimensions["D"].width = 50, 13, 13
            ws2.sheet_view.showGridLines = False
            wb2.save(os.path.join(self.regression_path,"03 RegressionTestFiles","Result","BCI2","Result_Parameters.xlsx"))
            wb2.close()
       
		
def main():  
    parser = argparse.ArgumentParser()
    parser.add_argument('-x','--rteexepath', dest='xmlfile',required=True,help="Provide config .xml file")
    parser.add_argument('-m', '--testmode', dest='mode', required=True, help='Provide execution mode')
    parser.add_argument('-s', '--systemtest', dest='system', required=True, help='Provide system name')
    

    options = parser.parse_args()
           
    task = RegressionTestExcution(options.xmlfile, options.mode, options.system)
    task.missing_parameter()
    
   
    
if __name__ == "__main__":
    main()
	